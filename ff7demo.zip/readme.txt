Final Fantasy VII Demo README File
----------------------------------

The Final Fantasy VII demo is a stand-alone demonstration of the battle 
system of Final Fantasy VII.  The demo will put you directly into the 
Battle Arena area of the game.  You will have to win a series of battles 
in order to "win" the demo.

This README file contains the latest technical information about 
playing the demo of Final Fantasy VII.

This README file covers the following topics:
1. System Requirements
2. Game Controls
3. How To Play
4. Technical Info 
5. Final Fantasy VII Technical Support and Web Site Information

======================
1. System Requirements
======================
The Final Fantasy VII demo has the following minimum system requirements:
Pentium 133 w/ supported 3D accelerator card (4Mb video memory or greater)
    or P166 w/out supported 3D accelerator card (see below)
Intel or 100% Intel-compatible CPU
32 Mb RAM
Windows 95
DirectX 5.1 (see below)
DirectMedia 5.2 (see below)
DirectX-compatible video and audio cards (see below)


================
2. Game Controls
================

You can play the demo of Final Fantasy VII with the keyboard or a game 
controller supported by DirectX 5.1.  The default keyboard commands 
all revolve around your Numeric Keypad.

KEYBOARD (default)
NumPad 8 (Up)    - Menu selection Up
NumPad 2 (Down)  - Menu selection Down
NumPad 4 (Left)  - Menu selection Left
NumPad 6 (Right) - Menu selection Right
NumPad Enter     - [OK] (Accept command)
NumPad 0         - [CANCEL] (Cancel command)
NumPad 9 (PgUp)  - [PAGEUP] (Page up in menu)
NumPad 3 (PgDn)  - [PAGEDOWN] (Page down in menu)
NumPad 1 (End)   - [TARGET] (Highlights targets in battle)
NumPad 5         - [START] (Pause during battle)
NumPad -         - [ASSIST] (Help window during battle)
CTRL+Q           - Quit

GAMEPAD (default)
Direction Pad    - Menu Selection
Right Button     - [OK] (Accept command)
Bottom Button    - [CANCEL] (Cancel command)
L1               - [PAGEUP] (Page up in menu)
R1               - [PAGEDOWN] (Page down in menu)
R2               - [TARGET] (Highlights targets in battle)
Start            - [START] (Pause during battle)
Select           - [ASSIST] (Help window during battle)


==============
3. How To Play
==============

To install the Final Fantasy VII demo, locate the directory in which you 
downloaded the FF7DEMO.ZIP file.  Extract the demo files from this file 
by using any unzip program.  Make sure that you have the unzip program 
extract the files into subdirectories instead of to just a single 
directory (see the unzip program documentation for more information).

Double-click on FF7DEMO.EXE to start the demo.

The FF7 Configuration program will run prior to entering the demo.  Please 
read the information in the Technical Info section below for information 
regarding the video and audio settings of your computer.  Click on OK to 
exit the Configuration program and enter the demo.

In the Battle Arena, you will control Cloud, the main character in Final 
Fantasy VII.

In Final Fantasy VII, the ATB (Active Time Battle) system is introduced. 
Whether ally or enemy, the character whose Time gauge fills up first is 
given priority for entering commands.  In the battle menu, choose any of 
the following commands in order to best attack or to defend yourself 
from the enemy.  

ATTACK
Cloud will attack with his sword.

LIMIT
The Limit gauge starts filling up with each enemy attack.  When the 
gauge is full, it blinks, indicating Limit Break status.  At this point, 
the "Attack" command changes to the "Limit" command.  By selecting 
the Limit command, Cloud will be able to perform his unique attack,  
called a Limit Break.  If the battle ends without using the Limit Break, 
you can carry it over to the next battle.  In this case, the Attack 
command will remain as the Limit command.  The more damage you sustain 
from the enemy, the faster the Limit gauge fills up. 

MAGIC
Select the magic you want, and select whom you wish to cast it on.  For 
instance, if it is attack magic, select the enemy to attack, and if it 
is curative magic, select one of your allies.  Magic effective on all 
enemies is indicated by a red arrow next to the name of the spell.  
If magic cannot be cast due to reasons such as insufficient MP, the name 
of the magic will be displayed in gray. 

SUMMON
Summon monsters will come to your aid and perform spectacular special 
attacks.  In the demo, you have two Summon monsters, Shiva and Hades.

ITEMS
Items that affect attacks and recovery can be used in battles.  Select 
an item and decide who will use it or against whom it will be used.  
If it is an attack item, select the enemy.  If it is a recovery item, 
select one of your allies. 

CHANGE
This command will appear if you press the left Directional Button at the 
left edge of the battle command window.  With this command, you can 
change the position of Cloud from the front line to the rear.  A character 
at the rear will incur less damage from the enemy, but his damage to 
the enemy when attacking will be less.  Placed at the front, the effect 
will be reversed.

DEFEND
This command will appear if you press the right Directional Button at 
the right edge of the battle command window.  If you use this command, 
damage incurred will be reduced by half until the Time gauge fills up. 

STATUS CHANGES
After (and sometimes during) battles, Cloud's health status may fall into 
"abnormal" status, such as Poison or Frog (Toad).  Abnormal status can 
be cured during battles using items such as Antidote or Maiden's Kiss.

WINNING BATTLES
Battles end when you have destroyed all the enemies in the battle.

GAME OVER
If Cloud wins enough battles, you will "win" the demo and see a special 
screen.  However, if Cloud's HP goes down to zero, the demo will end.


=================
4. Technical Info
=================

VIDEO CARDS

Supported 3D Accelerator Video Cards
The Final Fantasy VII demo currently supports 3D accelerator video cards 
that pass the criteria contained in the FF7 Configuration graphic card test.
At release time, the demo supports the cards that contain any of the 
following chipsets:
3Dfx Voodoo
3Dfx Voodoo2
3Dfx Voodoo Rush
3Dlabs Permedia2
ATI Rage Pro
Intel I740

In addition, the demo will support the following chipsets when they 
ship later this year:
Matrox G200
NEC PowerVR2

Please use the latest drivers for best performance of your 3D accelerator 
video card.  You can get the very latest drivers from the web sites of 
each of the 3D chip companies:
3Dfx: http://www.3dfx.com
3DLabs: http://www.3dlabs.com
ATI: http://www.atitech.com
Intel: http://www.intel.com
Matrox: http://www.matrox.com
NEC: http://www.powervr.com

If you do not have a supported 3D accelerator video card (or do not 
have a 3D accelerator video card), you can still play Final Fantasy VII 
in the software rendering mode.  The demo will automatically default 
to the software rendering mode if it does not detect a supported 3D 
accelerator video card.  To play in 640x480 (Full Screen) in the
software rendering mode, it is highly recommended that you have a 
Pentium 300 or better.  Otherwise, please select one of the other two
software rendering modes in the Configuration menu.

If you experience graphic display problems while playing the game, please
check to ensure that your 3D accelerator card has at least 4Mb of video
memory.

For ATI RagePro users, please run in 640x480 Full or Quarter Screen
mode.  These modes are faster than 320x240 Full Screen mode.  A P233 or higher
is recommended for RagePro users playing under hardware mode.

For users of Matrox Millenium (not supported but can run in software 
rendering mode), if you cannot run the FF7 Configuration program,
please uncheck the Bus Mastering box located in the PowerDesk settings 
in your Display Properties.

AUDIO CARDS
Final Fantasy VII supports all DirectX 5.1 supported audio cards.  
For a list of DirectX supported audio cards, please visit Microsoft's 
web site at:

http://www.microsoft.com/directx/pavilion/hardware/soundcardlist.htm

You should use the latest audio card drivers for your audio card.  You 
can get the very latest drivers from the web sites of the various audio 
card companies:
http://www.creativelabs.com
http://www.ensoniq.com
http://www.yamaha.com

You can change your audio default device settings through the Control Panel 
(under Multimedia).

DIRECTX, DIRECTMEDIA INFORMATION
To play the demo of Final Fantasy VII, you must have DirectX 5.1 
and DirectMedia 5.2 already installed on your computer.  If you do not 
already have these installed, you can download them from 
http://www.microsoft.com/directx/download.asp
and follow the directions provided at the Microsoft web site.

For additional DirectX or DirectMedia information, please visit 
Microsoft's web site at:
http://support.microsoft.com/support/directx

Windows 95, DirectX, and DirectMedia are trademarks of 
Microsoft Corporation in the U.S. and/or other countries.

WIN95 CONTROL KEYS
If you press ALT-TAB, ALT+ESC, CTRL+ENTER or the WINDOWS key on your 
keyboard while playing the demo, you may not be able to return properly 
to the game.  Therefore, it is strongly advised that you do not use these 
Windows 95 functions while playing the game. 

OTHER NOTES
It is strongly advised that you close all programs before playing the 
Final Fantasy VII demo.

Windows 95 note: You need to have the Audio Compression component of 
Multimedia installed.  Under Control Panel, click on Add/Remove Programs, 
click on the Windows Setup tab, click on Multimedia, click on Details, 
and check to see if the Audio Compression box is checked.  If the box 
is not checked, check the box and click OK.  Follow the instructions 
on the screen to complete installation.


===============================================================
5. Final Fantasy VII Technical Support and Web Site Information
===============================================================

There is no technical support for the Final Fantasy VII demo.

You can find general information about the game and the latest 
FAQ (Frequently Asked Questions) list and technical support information
at the Final Fantasy VII web site.

The official Final Fantasy VII PC web site is located at:
http://www.ff7pc.com

The official Eidos Interactive web site is located at: 
http://www.eidosinteractive.com

The official Square Soft, Inc. web site is located at: 
http://www.squaresoft.com
